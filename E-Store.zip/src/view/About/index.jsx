import Navbar from "../../components/Navbar/Navbar";
import styles from "./index.module.css";

export default function About() {
  return (
    <>
      <Navbar />
      <div className={styles.maindiv}>About page</div>
    </>
  );
}
